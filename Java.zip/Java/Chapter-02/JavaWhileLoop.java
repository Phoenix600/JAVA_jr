public class JavawhileLoop
{
  public static void main(String[] args)
  {
    System.out.printf("Java While Loop\n");

    int num = 1024;

    while(num != 1)
    {
      System.out.println(num);
      num = num / 2;
    }
    System.out.println("Time Complexity : 0(logn)");
  }
}
