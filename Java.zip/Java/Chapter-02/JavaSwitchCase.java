// Import java classes here 
import java.util.Scanner;

public class JavaSwitchCase
{
  public static void main(String[] args)
  {
    //Define the sacnner object here 
    Scanner input = new Scanner(System.in);
    
    System.out.println("Switch Case in Java");

    int num;

    System.out.println("Enter the size of your T-shirt : ");
    num = input.nextInt();


    switch (num) {
      case 30 : 
        System.out.println("Go the small size section --->");
        break;
      case 36 :
        System.out.println("Go to the medium size seciton ---->");
        break;
      case 40 :
        System.out.println("Go the extra+medium size section --->");
        break;
      case 46 :
        System.out.println("Go the large size section--->");
        break;
      default:
        System.out.println("Unkown size ---X");
        break;

    }
    
  }
}
