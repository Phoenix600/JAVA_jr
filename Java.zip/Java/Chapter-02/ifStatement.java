// Import java classes here 
import java.util.Scanner;

public class ifStatement
{
    public static void main(String[] args)
    {

        Scanner input = new Scanner(System.in);

        int age = 12;
        System.out.print("[+]Enter your age : ");
        age = input.nextInt();

        if(age > 18)
        {
          System.out.println("You can ride the rollar coaster");
        }
        else {
          System.out.println("You can not ride the rollar coaster");
        }
    }
}
