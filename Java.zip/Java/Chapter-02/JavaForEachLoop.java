public class JavaForEachLoop
{
  public static void main(String[] args)
  {

    // declaration of array in the java 
    int[] array = {12,13,14,145};

    for(int number : array)
    {
      System.out.println(number + " ");
    }
  }

}


/*
 * FOR EACH LOOP IN JAVA 
 * -----------------------
 *  For each loop is used to iterate through the elements of the array.
 *
 */
