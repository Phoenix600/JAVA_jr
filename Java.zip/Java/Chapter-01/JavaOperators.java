class JavaOperators{
  public static void main(String[] args)
  {
    System.out.println("Java Operator");
    int num1 = 12;
    int num2 = 13;

    System.out.println("The value of a + b : " + (num1 + num2));
    System.out.println("The value of a - b : " + (num1 -  num2));
    System.out.println("The value of a * b : " + (num1 * num2));
    System.out.println("The value of a / 2 : " + (num1 / 2));
    System.out.println("The value of b % a : " + (num1 % num2));

  }
}
