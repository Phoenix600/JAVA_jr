// Import java libraries here 


class JavaRelationalOperators
{
  public static void main(String[] args)
  {
    System.out.println("Java Relational Operators");

  
    int a = 12;
    int b = 13;

    System.out.println("The value of A : " + a);
    System.out.println("The value of B : " + b);
    System.out.println("The result of a == b  : " + (a==b));
    System.out.println("The result of a > b : " + (a>b));
    System.out.println("The result of a < b : " + (a < b));
    System.out.println("The result of a!=b : " + (a!=b));


    
    // Instance of operator 
    String str = "Program Villian";
    boolean result = str instanceof String;
    System.out.println("Is str is a object of string class : " +  result);

    String newString = result ? "Yes, Str is obejct of String Class..." : "No Str is not a obejct of class String";
    System.out.println("Result : " + newString);


  }
}
