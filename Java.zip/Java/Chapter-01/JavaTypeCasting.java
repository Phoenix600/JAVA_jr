import java.util.Scanner;

public class JavaTypeCasting {
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);

        // The process of converting one type of data into the anotgher tpye of data is called 
        // type-conversion.

        String name = input.next();
        System.out.println("Your name is : " + name);

    
        input.close();
    }
}
