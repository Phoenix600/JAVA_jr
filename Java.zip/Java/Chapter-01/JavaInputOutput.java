// Import java classes here 
import java.util.Scanner;


class JavaInputOutput
{
  public static void main(String[] args)
  {
    
    System.out.println("Basic Java Input Output Lesson");

    // Define Basic Scanner Object Here 
    Scanner input = new Scanner(System.in);
    
    // declare variables here 
    int salary;

    System.out.print("Enter your future salary : ");
    salary = input.nextInt();

    System.out.println("You entered your salary as : "+ salary);
    
    System.out.print("Enter your age : ");
    int age = input.nextInt();

    boolean allow = age > 18 ? true : false;

    System.out.printf("\nYour age is %d, so age-wise your entry status is %b \n",age,allow);

    String name;
    System.out.print("Enter your full name : ");
    name = input.next();

    System.out.println("Wooo, Hello " + name + " How is it going ?");


    input.close();

  }

}


// Here are some my Notes 
/*
 * System.out.println("This is sample message");
 * here : 
 *  # Basic Output in java 
 *  -----------------------------------------------------------------------
 *  we use println / printf / print to print the output in java programe 
 *  System   : is a java class 
 *  out      : is a public static field that accepts the output data 
 *  ----------------------------------------------------------------------
 *  # Basic java Input
 *  Java provides different ways to get input from the user
 *  We will use the Scanner class object to take input from the user.
 *  To use the object of scanner class, import java.util.Scanner class 
 *  Simple Syntax to create the obejct of Sacnner class 
` *  Scanner Input = new Scanner(System.in);
 *  
 *  : How things are happening here is 
 *    First we declare the Scanner Type object and allocate the object with new keyword
 *    then We'll call the constructor of class Scanner with these parameters, which basically means
 *    the create the object of Scanner class which will take the input from the System. which can be
 *    shown by System.in 
 *
 *    once the purpose of Sacnner object is finished it's a good practice to close it 
 *    Ex. input.close();
 */
